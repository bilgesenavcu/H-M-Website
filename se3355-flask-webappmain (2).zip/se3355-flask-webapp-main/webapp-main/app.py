from flask import Flask, render_template, send_from_directory, request, redirect, url_for
import mysql.connector
from flask import jsonify


app = Flask(__name__)

# Veritabanı bağlantısı
connection = mysql.connector.connect(
    host="localhost",
    user="root",
    password="12345678",
    database="sys"
)


def get_products_by_category(category):
    cursor = connection.cursor()
    cursor.execute("SELECT filename, filepath, name, price FROM images WHERE category = %s", (category,))
    products = cursor.fetchall()
    cursor.close()
    return products

def get_products_by_name(product_name):
    cursor = connection.cursor()
    cursor.execute("SELECT filename, filepath, name, price FROM images WHERE name LIKE %s", ("%" + product_name + "%",))
    products = cursor.fetchall()
    cursor.close()
    return products

def get_all_products():
    cursor = connection.cursor()
    cursor.execute("SELECT filename, filepath, name, price FROM images")
    products = cursor.fetchall()
    cursor.close()
    return products

def get_product_by_id(product_id):
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM images WHERE id = %s", (product_id,))
    product = cursor.fetchone()  # ID'ye göre tek bir ürün al
    cursor.close()
    return product  # Tek bir ürün döndür


def get_products_by_size(beden):
    cursor = connection.cursor()
    query = "SELECT * FROM images WHERE beden = %s"
    cursor.execute(query, (beden,))
    # Sonuçları al
    products = cursor.fetchall()

    # Bağlantıyı kapat
    cursor.close()
    connection.close()

    return products


def get_products():
    cursor = connection.cursor()
    cursor.execute("SELECT price FROM products")  # Ürünlerin fiyatlarını çekiyoruz, diğer gerekli alanları da ekleyebilirsiniz
    products = cursor.fetchall()
    cursor.close()
    return products


   



@app.route('/')
def home():
    # Kadın kategorisindeki ürünleri al
    women_products = get_products_by_category('Kadın')

    # Erkek kategorisindeki ürünleri al
    erkek_products = get_products_by_category('Erkek')

    # Divided kategorisindeki ürünleri al
    divided_products = get_products_by_category('Divided')

    bebek_products = get_products_by_category('Bebek')

    # Çocuk kategorisindeki ürünler
    cocuk_products = get_products_by_category('Çocuk')
    
    hmhome_products = get_products_by_category('H&MHome')
    spor_products = get_products_by_category('Spor')
    
    
    return render_template('index.html', women_products=women_products, erkek_products=erkek_products, divided_products=divided_products, bebek_products=bebek_products, cocuk_products=cocuk_products,hmhome_products=hmhome_products,spor_products=spor_products)




@app.route('/get_products_by_category', methods=['POST'])
def get_products_by_category_route():
    if request.method == 'POST':
        category = request.json.get('category')
        products = get_products_by_category(category)
        # Döndürülen veriyi jsonify ile JSON formatına dönüştür
        return jsonify(products)
    else:
        return jsonify({'error': 'Method not allowed'}), 405
    
    
    
@app.route('/product_detail/<product_id>')
def product_detail(product_id):
    product = get_product_by_id(product_id) 
    return render_template('detail.html', product=product)    


@app.route('/search', methods=['POST'])
def search():
    if request.method == 'POST':
        # Formdan arama terimini al
        search_term = request.form.get('search_term')

        # Eğer arama terimi varsa
        if search_term:
            # Arama terimini query parametresi olarak ekleyerek search_results sayfasına yönlendir
            return redirect(url_for('search_html', q=search_term))

    # Arama terimi yoksa veya search_results sayfası bulunamazsa ana sayfaya yönlendir
    return redirect(url_for('home'))
    
@app.route('/search_results')
def search_html():
    # Arama terimini al
    search_term = request.args.get('q')

    # Arama sonuçlarını al
    products = get_products_by_name(search_term)

    # Eğer arama sonuçları yoksa veya boşsa, ana sayfaya yönlendir
    if not products:
        return redirect(url_for('home'))

    return render_template('search.html', search_term=search_term, products=products)


@app.route('/get_all_products', methods=['GET'])
def get_all_products_route():
    products = get_all_products()
    return jsonify(products)

@app.route('/get_products_by_size', methods=['POST'])
def get_products_by_size_route():
    request_data = request.get_json()
    beden = request_data.get('beden')
    products = get_products_by_size(beden)
    return jsonify(products)


@app.route('/sort_products', methods=['POST'])
def sort_products():
    order = request.json.get('order')  # JavaScript tarafından gönderilen sıralama yöntemi
    # Veritabanından ürünleri çek
    products = get_products()
    # Ürünleri sırala
    if order == 'asc':
        sorted_products = sorted(products, key=lambda x: x[0])  # İlk sütunu fiyata göre sırala
    elif order == 'desc':
        sorted_products = sorted(products, key=lambda x: x[0], reverse=True)  # Azalan sıralama
    else:
        return jsonify({'error': 'Geçersiz sıralama yöntemi'})

    return jsonify(sorted_products)


@app.route('/images/<path:filename>')
def get_image(filename):
    return send_from_directory('images', filename)



if __name__ == '__main__':
    app.run(debug=True)
